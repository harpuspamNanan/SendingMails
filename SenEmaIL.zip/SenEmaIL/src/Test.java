
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String [] recepients =new String[]{"lambtoncollegeintoronto@gmail.com"};
		String [] bccRecepients =new String[]{"lambtoncollegeintoronto@gmail.com"};
		String subject ="hi";
		String message ="this is test mail from shiva";
		
		new SendEmail().sendMail(recepients, bccRecepients, subject, message);
	}

}
